package com.yyh.fileselector.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.yyh.fileselector.R;
import com.yyh.fileselector.logic.CustomFileSelect;
import com.yyh.fileselector.logic.bean.SelectedFiles;
import com.yyh.fileselector.util.SDCardScanner;
import com.yyh.fileselector.util.StringUtil;
import com.yyh.fileselector.util.UIAction;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @describe: 文件管理界面(内部存储 、 存储卡)
 * @author: yyh
 * @createTime: 2019/8/7 15:14
 * @className: FileHomeActivity
 */
public class FileHomeActivity extends AppCompatActivity implements View.OnClickListener {

    private String mInternalPath;//内部存储路径
    private String mExternalPath;//外部存储路径(sd卡)

    private boolean mIsMulSelect;//是否支持多选标识

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sdk_activity_file_select_home);
        initData();
        initView();
    }

    private void initData() {
        Intent intent = getIntent();
        if (intent.hasExtra(CustomFileSelect.FILE_SELECT_ISMULSELECT)) {
            this.mIsMulSelect = intent.getBooleanExtra(CustomFileSelect.FILE_SELECT_ISMULSELECT, false);
        }
    }


    private void initView() {
        UIAction.setTitleBarLeftImgBtn(getWindow().getDecorView(), R.mipmap.sdk_ico_back, this);
        ((TextView) findViewById(R.id.sdk_title_text)).setText("全部文件");

        View internalView = findViewById(R.id.storage_internal_view);
        View externalView = findViewById(R.id.storage_external_view);
        View emptyTipView = findViewById(R.id.no_storage_empty_tip_view);
        internalView.setOnClickListener(this);
        externalView.setOnClickListener(this);

        //获取内部存储路径信息
        List<String> paths = SDCardScanner.getExtSDCardPaths();
        if (paths != null && !paths.isEmpty()) {
            try {
                mInternalPath = paths.get(0);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("SDCardScanner", "Exception", e.fillInStackTrace());
            }
        }
        //获取外部存储路径信息
        mExternalPath = SDCardScanner.getStoragePath(this, true);
        if (StringUtil.isNullOrEmpty(mInternalPath) && StringUtil.isNullOrEmpty(mExternalPath)) {
            emptyTipView.setVisibility(View.VISIBLE);
            return;
        }
        if (StringUtil.isNullOrEmpty(mInternalPath)) {
            internalView.setVisibility(View.GONE);
        } else {
            internalView.setVisibility(View.VISIBLE);
        }
        if (StringUtil.isNullOrEmpty(mExternalPath)) {
            externalView.setVisibility(View.GONE);
        } else {
            externalView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (viewId == R.id.sdk_title_left_img_btn) {
            finish();
            return;
        } else if (viewId == R.id.storage_internal_view) {
            CustomFileSelect.FILE_ROOT_PATH = mInternalPath;
        } else if (viewId == R.id.storage_external_view) {
            CustomFileSelect.FILE_ROOT_PATH = mExternalPath;
        }
        Intent intent = new Intent(this, FileSelectActivity.class);
        intent.putExtra(CustomFileSelect.FILE_SELECT_ISMULSELECT, mIsMulSelect);
        startActivityForResult(intent, CustomFileSelect.FILE_SELECT_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CustomFileSelect.FILE_SELECT_REQUEST_CODE) {//选择文件后返回
            if (SelectedFiles.files != null && !SelectedFiles.files.isEmpty()) {
                ArrayList<String> list = new ArrayList<>();
                for (File file : SelectedFiles.files.values()) {
                    if (file != null) {
                        list.add(file.getAbsolutePath());
                    }
                }
                Intent intent = new Intent();
                intent.putStringArrayListExtra(CustomFileSelect.FILE_SELECT_RESULT, list);
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
            SelectedFiles.files = null;
            SelectedFiles.totalFileSize = 0;
            CustomFileSelect.FILE_ROOT_PATH = "";
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}