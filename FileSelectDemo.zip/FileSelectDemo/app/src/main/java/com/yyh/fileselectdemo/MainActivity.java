package com.yyh.fileselectdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.yyh.fileselector.logic.CustomFileSelect;
import com.yyh.fileselector.util.StringUtil;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView mResultView;

    private ArrayList<String> mFiles = new ArrayList<String>();//已选择集合

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.select).setOnClickListener(this);
        mResultView = (TextView) findViewById(R.id.result_view);
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (viewId == R.id.select) {
            //设置选择历史记录
            CustomFileSelect.getInstance().setFilePaths(mFiles);
            CustomFileSelect.actionSelectFile(this,
                    CustomFileSelect.FILE_SELECT_REQUEST_CODE,
                    CustomFileSelect.FILE_SELECT_RESULT, true);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CustomFileSelect.FILE_SELECT_REQUEST_CODE) {//获取文件选择结果
            if (data == null) {
                return;
            }
            mFiles = data.getStringArrayListExtra(CustomFileSelect.FILE_SELECT_RESULT);
            if (mFiles != null && !mFiles.isEmpty()) {
                StringBuffer stringBuffer = new StringBuffer();
                for (String path : mFiles) {
                    if (!StringUtil.isNullOrEmpty(path)) {
                        stringBuffer.append(path).append("\n");
                    }
                }
                mResultView.setText(stringBuffer.toString());
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}
